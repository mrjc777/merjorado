create function get_all_tariffheadings() returns json
    language plpgsql
as
$$
declare
	response json;
begin
	response :=(select array_to_json(array_agg(data))
					from(select tariff_heading, description from public.tariffheadings
							where deleted_date is null
						) as data
			   );
return response;
end
$$;

alter function get_all_tariffheadings() owner to postgres;

