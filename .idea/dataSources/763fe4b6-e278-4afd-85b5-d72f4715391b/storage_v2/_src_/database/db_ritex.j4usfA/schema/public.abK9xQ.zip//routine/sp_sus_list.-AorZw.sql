create function sp_sus_list(pa_auth json, pa_accion character varying, pa_datos json) returns json
    language plpgsql
as
$$
DECLARE
	-- DEFINICION DE VARIABLES GLOBALES
    paidrol INTEGER DEFAULT (pa_auth->>'idsro')::INT;
    paidsus INTEGER DEFAULT (pa_auth->>'idsus')::INT;
    paurl VARCHAR DEFAULT (pa_auth->>'url');
    response json DEFAULT '[]';
    pd json DEFAULT pa_datos; -- variable utilizada para los datos
BEGIN
    --  VERIFICAMOS SI EL USUARIO PUEDE INGRESAR AL MODULO
    -- PERFORM fn_verificar_acceso(paidrol, paidsus, paidemp, paurl);
    
    -- INGRESAMOS LAS ACCIONES DEFINIDAS PARA LISTADO
    CASE (upper(pa_accion))
    WHEN 'MENUS' THEN
    	/*******************************************
    	 * GENERAMOS EL LISTADO DE MENUS DE ACCESO DE UN DETERMINADO USUARIO
    	 * REQUIERE idrol para el funcionamiento
    	 *******************************************/
    	BEGIN
    		SELECT COALESCE(json_agg(tbl), '[]') INTO response 
            FROM (
                SELECT sp.idspg, sp.short_name, sp.name_page, sp.type_page, sp.icon_type,
                       sp.route_url, sp.order_page, sp.description,
                       (
                               SELECT COALESCE(json_agg(x), '[]')
                               FROM(
                                   SELECT sp2.idspg, sp2.parent_pag, sp2.short_name, sp2.name_page,
                                       sp2.type_page, sp2.icon_type, sp2.route_url, sp2.order_page,
                                       sp2.description,
                                       (
                                            SELECT COALESCE(json_agg(y), '[]') 
                                            FROM(
                                                SELECT sp3.idspg, sp3.parent_pag, sp3.short_name,
                                                       sp3.name_page, sp3.type_page, sp3.icon_type,
                                                       sp3.route_url, sp3.order_page,
                                                       sp3.description, '[]' children
                                                FROM seg_pages AS sp3
                                                INNER JOIN seg_rol_pages AS srp3 ON srp3.idspg = sp3.idspg AND srp3.idsro = paidrol
                                                WHERE sp3.parent_pag = sp2.idspg AND sp3.apistate IN ('ELABORADO')
                                            ) y
                                       ) children
                                FROM seg_pages AS sp2
                                INNER JOIN seg_rol_pages AS srp2 ON srp2.idspg = sp.idspg AND srp2.idsro = paidrol
                                WHERE sp2.parent_pag = sp.idspg AND sp2.apistate IN ('ELABORADO')
                                ORDER BY sp2.order_page    
                               ) x     
                       ) children
                FROM seg_pages AS sp
                INNER JOIN seg_rol_pages AS srp ON srp.idspg = sp.idspg AND srp.idsro = paidrol
                WHERE sp.parent_pag IS NULL AND sp.apistate IN ('ELABORADO')
                ORDER BY sp.order_page
            ) tbl;
    	END;
    END CASE;
    
    IF(response IS NULL)
    THEN
        raise EXCEPTION '##Error!! response is NULL##';
    END IF;
    
    RETURN response;
    
END;
$$;

alter function sp_sus_list(json, varchar, json) owner to postgres;

