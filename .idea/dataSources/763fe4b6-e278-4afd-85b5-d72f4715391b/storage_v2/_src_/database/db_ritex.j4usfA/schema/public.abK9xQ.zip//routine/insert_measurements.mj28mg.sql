create function insert_measurements(unit character varying, description character varying) returns response
    language plpgsql
as
$$
declare
		response RESPONSE;
		existe integer;
		measurement_pk integer;
BEGIN
		response.type := 'error';
		response.message := 'Error en el registro de la Unidad de Medida';
		select count (id) from public.measurements
			where deleted_date is null and
			unit_measurement = $1
					into existe;
		if existe > 0 then
			response.message := 'La unidad de medida ya se encuentra registrada en la base de datos';
			response.data := json_build_array();
			return response;
		end if;
		insert into public.measurements(unit_measurement, description, created_date)
			values (UPPER ($1), $2, current_timestamp)
		returning id into measurement_pk;
		response.type := 'success';
		response.message := 'La informacion fue registrada con exito';
		response.data := (
				select array_to_json(array_agg(m))
				from(
						select * from public.measurements where id = measurement_pk
				) as m
		);
		return response;
END
$$;

alter function insert_measurements(varchar, varchar) owner to postgres;

