create view v_seg_users
            (idsus, username, password, user_active, remember_token, fl_name, ci, email, office, user_role, idsro) as
SELECT su.idsus,
       su.username,
       su.password,
       su.user_active,
       su.remember_token,
       concat(sp.first_name, ' ', sp.last_name)     AS fl_name,
       sp.ci,
       sp.email,
       sp.office,
       concat(sr.short_role, ' - ', sr.description) AS user_role,
       sr.idsro
FROM seg_users su
         JOIN seg_persons sp ON sp.idspe = su.idspe
         JOIN seg_user_restrictions sur ON sur.idsus = su.idsus AND sur.active_rol = 1
         JOIN seg_roles sr ON sr.idsro = sur.idsro;

alter table v_seg_users
    owner to postgres;

