create function insert_companies(business character varying, direction character varying, city character varying, stat character varying, phone character varying, activity character varying, legal character varying, email character varying, ruex character varying, enrollment character varying, nit character varying) returns json
    language plpgsql
as
$$
declare
	response RESPONSE;
	existe integer;
	company_pk integer;
BEGIN

return json_build_object(
	'type', 'success',
	'message', 'Menjsae de prueba',
	'data', json_build_array()
);
	response.type := 'error';
	response.message := 'Error en el Pre Registro de la Empresa';
	select count(id)from public.companies 
		where deleted_date is null and
		UPPER (business_name) = UPPER ($1) and
		nit_number = $11 
			   into existe;
	if  existe > 0 then
		response.message := 'La empresa ya existe con los datos ingresados y/o ya fue rechazada anteriormente';
		response.data := json_build_array();
		return response;
	end if;
	insert into public.companies(business_name, direction, city, state, phone, activity, legal_representative,
								email, ruex_number, enrollment_number, nit_number, created_date
								) values (UPPER ($1), $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, current_timestamp)
	returning id into company_pk;
	response.type := 'success';
	response.message := 'Los datos se registraron de manera correcta, los tecniso se comunicaran con el representante leega';
	response.data := (
		select array_to_json(array_agg(d))
		from(
			select * from public.companies where id = company_pk
		) as d
	);	
	return response;
END
$$;

alter function insert_companies(varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar) owner to postgres;

