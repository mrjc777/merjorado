create function insert_tariffheadings(tariffheading character varying, description character varying) returns response
    language plpgsql
as
$$
declare
		response RESPONSE;
		existe integer;
		tariff_pk integer;
BEGIN
		response.type := 'error';
		response.message := 'Error en el registro de la tarifa';
		select count(id) from public.tariffheadings
			where deleted_date is null and 
			tariff_heading = $1
				into existe;
		if existe > 0 then
			response.message := 'La tarifa arancelaria ya existe';
			response.data := json_build_array();
			return response;
		end if;
		insert into public.tariffheadings(tariff_heading, description, created_date)
			values ($1, $2, current_timestamp)
		returning id into tariff_pk;
		response.type := 'success';
		response.message := 'Los datos se registraron de forma correcta';
		response.data := (
				select array_to_json(array_agg(t))
				from (
						select * from public.tariffheadings where id = tariff_pk	
				) as t
		);
		return response;
END
$$;

alter function insert_tariffheadings(varchar, varchar) owner to postgres;

