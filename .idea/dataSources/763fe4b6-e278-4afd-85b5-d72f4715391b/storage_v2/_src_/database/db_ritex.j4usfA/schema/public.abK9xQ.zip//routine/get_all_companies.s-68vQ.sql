create function get_all_companies() returns json
    language plpgsql
as
$$
declare
	response json;
begin
	response :=(select array_to_json(array_agg(data))
				from(select business_name, activity, nit_number from public.companies
					 where deleted_date is null
					) as data
			   );
			   
return response;
end
$$;

alter function get_all_companies() owner to postgres;

