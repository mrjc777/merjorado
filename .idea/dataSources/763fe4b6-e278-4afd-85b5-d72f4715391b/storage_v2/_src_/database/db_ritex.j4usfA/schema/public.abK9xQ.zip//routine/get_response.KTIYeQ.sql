create function get_response() returns response
    language plpgsql
as
$$
declare
	response RESPONSE;
BEGIN
	response.type := 'success';
	response.message := 'Registro Exitoso';
	response.data := (
		select array_to_json(array_agg(d))
		from(
			select * from companies
		) as d
	);
	if response.data is null then
		response.data = json_build_array();
	end if;
	return response;
END
$$;

alter function get_response() owner to postgres;

